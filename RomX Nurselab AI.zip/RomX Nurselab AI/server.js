
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { OpenAI } = require('openai');

const app = express();
const port = process.env.PORT || 5000;

const openai = new OpenAI({
  apiKey: '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'
});

app.use(cors());
app.use(bodyParser.json());

app.post('/api/query', async (req, res) => {
  const userQuery = req.body.query;
  if (!userQuery) {
    return res.status(400).json({ error: 'Query is required' });
  }

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: 'You are RomX Nurselab AI, a professional assistant for nursing, midwifery, and medicine. Provide clear, concise, and evidence-based information.' },
        { role: 'user', content: userQuery }
      ],
      temperature: 0.3,
      max_tokens: 800
    });

    const result = completion.choices[0].message.content;
    res.json({ response: result });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to get response from AI' });
  }
});

app.listen(port, () => {
  console.log(`RomX Nurselab API server running on port ${port}`);
});
